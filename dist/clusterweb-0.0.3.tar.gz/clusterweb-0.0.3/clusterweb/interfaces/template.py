 #!/bin/env/python
 #-*- encoding: utf-8 -*-
 """

 """
from __future__ import print_function
from __future__ import division
import sys
import os

"""
===============================================================================

===============================================================================
"""

class Interface():

	def __init__(self):
		pass

	#--------------------------------------------------------------------------

	def send(self):
		pass

	#--------------------------------------------------------------------------

	def recieve(self):
		pass