 #!/bin/env/python
 #-*- encoding: utf-8 -*-
 """

 """
from __future__ import print_function
from __future__ import division
import numpy as np
import subprocess
import sys
import os
import re

"""
===============================================================================

===============================================================================
"""


class OSCServer():

	def __init__(self):
		pass

"""
===============================================================================

===============================================================================
"""

class OSCClient():


	def __init__(self):
		pass

"""
===============================================================================

===============================================================================
"""

class Node(object):

	def __init__(self):
		pass

	def init_client(self):
		pass

	def init_server(self):
		pass



"""
===============================================================================

===============================================================================
"""

class NodeServer(object):

	def __init__(self):
		pass

	def init_client(self):
		pass

	def init_server(self):
		pass

"""
===============================================================================

===============================================================================
"""

class LocalSystem():

	def __init__(self):
		pass

	def create_nodes(self,ports):
		pass